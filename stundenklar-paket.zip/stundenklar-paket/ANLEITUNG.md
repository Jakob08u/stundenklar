# Stundenklar online stellen – Schritt für Schritt

Mit diesem Paket läuft Stundenklar als eigene Website. Die App öffnet Stellenanzeigen per Link und holt echte Stellen aus der Jobbörse der Bundesagentur für Arbeit. Jede Stelle wird direkt auf dem Handy für die Person geprüft.

**Ihr braucht:** etwa 20 Minuten, einen Laptop, eine E-Mail-Adresse. Beide Konten sind kostenlos.

```
stundenklar-paket/
├── ANLEITUNG.md            ← diese Datei
├── website/                ← alles hier drin kommt zu GitHub
│   ├── index.html          die App zum Ausprobieren
│   ├── demo.html           die Demo mit Mia, Leon und Sara
│   ├── config.js           HIER tragt ihr die Adresse des Link-Dienstes ein
│   ├── datenschutz.html    vor dem Veröffentlichen ausfüllen
│   ├── impressum.html      vor dem Veröffentlichen ausfüllen
│   ├── manifest.webmanifest, icons/, fonts/
│   └── README.md
└── link-dienst/
    ├── worker.js           der Link-Dienst für Cloudflare
    └── wrangler.toml       nur nötig, wenn ihr mit der Kommandozeile arbeitet
```

---

## Schritt 1: Impressum und Datenschutz ausfüllen

Öffnet `website/impressum.html` und `website/datenschutz.html` mit einem Texteditor (zum Beispiel VS Code oder Notepad++). Ersetzt alles in eckigen Klammern, zum Beispiel `[Vorname Nachname]`, durch eure echten Angaben.

- Fragt eure Schule, ob ihr ihre Adresse angeben dürft. Sonst braucht ihr eine eigene ladungsfähige Anschrift.
- Tragt bei der Aufsichtsbehörde die Datenschutzbehörde eures Bundeslands ein, in NRW zum Beispiel „Landesbeauftragte für Datenschutz und Informationsfreiheit Nordrhein-Westfalen“.

## Schritt 2: Link-Dienst bei Cloudflare einrichten

1. Geht auf **dash.cloudflare.com**, legt ein Konto an und bestätigt eure E-Mail.
2. Links im Menü: **Workers & Pages** (manchmal unter „Compute“) → **Create** → **Worker** → Vorlage **„Hello World“**.
3. Name: `stundenklar-dienst` → **Deploy**.
4. Auf **Edit code** klicken. Löscht den ganzen Beispielcode, kopiert den kompletten Inhalt von `link-dienst/worker.js` hinein und klickt **Deploy**.
5. Oben steht jetzt die Adresse eures Dienstes, etwa
   `https://stundenklar-dienst.euer-name.workers.dev`. Kopiert sie.
6. Test: Öffnet die Adresse im Browser. Ihr solltet so etwas sehen:
   `{"dienst":"stundenklar-link-dienst","version":"1.0","ok":true,"herkunftErlaubt":false}`
7. Unter **Settings → Observability** die **Workers Logs** ausschalten, falls sie an sind. Sonst speichert Cloudflare für euch eine Liste der Anfragen, mit Suchwort und Ort. Genau das wollen wir nicht.

## Schritt 3: Adresse in die App eintragen

Öffnet `website/config.js` und schreibt eure Adresse zwischen die Anführungszeichen:

```js
window.STUNDENKLAR_DIENST = "https://stundenklar-dienst.euer-name.workers.dev";
```

Speichern. Mehr müsst ihr am Code nicht ändern.

## Schritt 4: Website bei GitHub Pages veröffentlichen

1. Geht auf **github.com** und legt ein Konto an.
2. Oben rechts **+** → **New repository**. Name: `stundenklar`, **Public**, dann **Create repository**.
3. Auf der leeren Seite auf **„uploading an existing file“** klicken.
4. Zieht **den Inhalt** des Ordners `website/` in das Fenster: alle Dateien **und** die Ordner `fonts` und `icons`. Dann **Commit changes**.
5. Im Repository: **Settings → Pages**. Bei „Source“ **Deploy from a branch**, Branch **main**, Ordner **/ (root)** → **Save**.
6. Nach ein bis zwei Minuten ist die App online:
   - App: `https://euer-name.github.io/stundenklar/`
   - Demo: `https://euer-name.github.io/stundenklar/demo.html`

## Schritt 5: Nur eure Website freischalten

Damit nur eure Seite den Link-Dienst nutzen darf:

1. Cloudflare → euer Worker → **Settings → Variables and Secrets → Add**.
2. Typ **Text**, Name `ALLOWED_ORIGINS`, Wert `https://euer-name.github.io`
   (ohne `/stundenklar` und ohne Schrägstrich am Ende).
3. **Deploy**.

Ohne diese Einstellung lässt der Dienst alle Seiten auf `github.io` zu.

## Schritt 6: Testen

1. App auf dem Handy öffnen → **Profil → Link-Dienst** muss **„Verbunden“** zeigen.
2. **Job-Check → Anzeige → Passende Jobs suchen**: Ort eingeben, suchen. Es erscheinen echte Stellen mit Ampel.
3. Einen Link aus der Jobbörse einfügen, etwa `https://www.arbeitsagentur.de/jobsuche/jobdetail/…`, und **Prüfen** tippen.

| Die App zeigt … | Lösung |
|---|---|
| „Nicht erreichbar“ | Adresse in `config.js` prüfen. Ist der Worker veröffentlicht (Schritt 2.4)? |
| „Website nicht freigeschaltet“ | `ALLOWED_ORIGINS` muss genau `https://euer-name.github.io` sein. |
| „Diese Seite erlaubt kein automatisches Lesen“ | Richtig so: Das Portal verbietet es in seiner robots.txt. Text der Anzeige einfügen. |
| Änderungen sind nicht zu sehen | Ein bis zwei Minuten warten, dann neu laden. |

**Tipp:** Auf dem iPhone in Safari **Teilen → Zum Home-Bildschirm**. Dann startet Stundenklar wie eine App.

---

## Für den Pitch

- Zeigt die Demo von eurer Website (`…/demo.html`). Dort sucht „Passende Jobs finden“ echte Stellen in Ahaus, Nordhorn oder Kassel und prüft sie für Mia, Leon oder Sara.
- Testet einmal im Schul-WLAN. Manche Schulnetze sperren fremde Dienste. Ein Handy-Hotspot ist der Plan B.
- Fällt das Internet aus, zeigt die Demo automatisch die erfundenen Beispiel-Stellen. Nichts bricht ab.

## Was der Link-Dienst kann und was nicht

- **Jobbörse der Arbeitsagentur:** Suche und Details laufen über die Schnittstelle, die auch die Jobbörse-App nutzt. Sie ist nicht offiziell dokumentiert ([bundesAPI/jobsuche-api](https://github.com/bundesAPI/jobsuche-api)) und kann sich ändern. Dann zeigt die App statt der Liste einen Link zur fertigen Suche auf arbeitsagentur.de. Für einen echten Start solltet ihr bei der Bundesagentur nach einer Kooperation fragen.
- **Andere Portale:** Der Dienst liest die öffentliche Seite und nutzt bevorzugt die strukturierten Stellendaten (schema.org „JobPosting“), die viele Portale für Suchmaschinen einbauen. Er beachtet die robots.txt. Große Portale wie Indeed, StepStone oder LinkedIn verbieten automatisches Lesen oft. Dann fügt man den Text ein.
- **Kosten:** Der kostenlose Cloudflare-Tarif erlaubt 100.000 Anfragen pro Tag. Für ein Schulprojekt reicht das locker.

## Datenschutz in einem Satz

Name, Alter, Status, Stunden und Familie bleiben auf dem Handy. Der Link-Dienst bekommt nur einen Link oder Suchwort und Ort, speichert nichts und gibt das Ergebnis sofort zurück.

Was ihr noch prüfen solltet:
- GitHub und Cloudflare übertragen Daten in die USA. Grundlage ist das EU-US Data Privacy Framework. Das Gericht der EU hat es im September 2025 bestätigt, ein Rechtsmittel beim Europäischen Gerichtshof läuft noch. Schaut vor dem Veröffentlichen kurz auf dataprivacyframework.gov, ob beide Firmen dort gelistet sind.
- Die Schrift Inter liegt im Ordner `fonts`. Es wird nichts von Google geladen. Die Lizenz (SIL Open Font License) liegt daneben.
- Stundenklar gibt allgemeine Informationen, keine Rechtsberatung.

## Für Neugierige: Kommandozeile statt Browser

Wer Node.js hat, kann den Worker auch so veröffentlichen:

```bash
cd link-dienst
npx wrangler login
npx wrangler deploy
```

Vorher in `wrangler.toml` bei `ALLOWED_ORIGINS` eure GitHub-Adresse eintragen.
