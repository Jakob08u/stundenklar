/**
 * Stundenklar Link-Dienst – Cloudflare Worker
 * ------------------------------------------------------------------
 * Was er macht:
 *   GET /                 Status: Läuft der Dienst? Ist diese Website freigeschaltet?
 *   GET /anzeige?url=…    Liest EINE öffentliche Stellenanzeige und gibt Titel,
 *                         Arbeitgeber, Ort, Lohn und Text zurück.
 *   GET /jobs?was=…&wo=…  Sucht Stellen in der Jobbörse der Bundesagentur für Arbeit
 *                         (optional: umkreis, angebotsart, arbeitszeit, anzahl, details).
 *
 * Was er NICHT macht:
 *   – nichts speichern: keine Datenbank, keine Cookies, kein Cache, keine Logs mit Inhalten
 *   – keine persönlichen Daten annehmen: Alter, Name und Stunden bleiben in der App
 *   – keine Seiten lesen, die automatischen Zugriff per robots.txt verbieten
 *
 * Einstellung (Cloudflare → Workers → euer Worker → Settings → Variables and Secrets):
 *   ALLOWED_ORIGINS = https://euername.github.io      (mehrere mit Komma trennen)
 *   Ohne Einstellung sind alle *.github.io-Seiten und localhost erlaubt.
 */

const VERSION = "1.0";
const BA_BASE = "https://rest.arbeitsagentur.de/jobboerse/jobsuche-service";
const BA_KEY = "jobboerse-jobsuche";           // öffentlicher Schlüssel der Jobbörse-App
const BA_WEB = "https://www.arbeitsagentur.de/jobsuche/jobdetail/";
const UA_TOKEN = "StundenklarLinkDienst";
const UA = `${UA_TOKEN}/${VERSION} (Schulprojekt; liest einzelne oeffentliche Stellenanzeigen auf Anfrage)`;
const MAX_PAGE_BYTES = 2_000_000;
const MAX_TEXT = 15_000;
const MAX_DESC = 6_000;
const TIMEOUT_MS = 9_000;

export default {
  async fetch(request, env) {
    const origin = request.headers.get("Origin");
    const allowed = originAllowed(origin, env);
    const cors = allowed
      ? { "Access-Control-Allow-Origin": origin, "Vary": "Origin", "Access-Control-Allow-Methods": "GET, OPTIONS", "Access-Control-Max-Age": "86400" }
      : {};
    if (request.method === "OPTIONS") return new Response(null, { status: allowed ? 204 : 403, headers: cors });
    if (request.method !== "GET") return reply({ fehler: "methode" }, 405, cors);

    const url = new URL(request.url);
    const path = url.pathname.replace(/\/+$/, "") || "/";
    if (path === "/") {
      // Status darf jede Seite lesen, damit die App beim Einrichten sagen kann, was fehlt.
      return reply({ dienst: "stundenklar-link-dienst", version: VERSION, ok: true, herkunftErlaubt: allowed }, 200, { "Access-Control-Allow-Origin": "*" });
    }
    if (!allowed) return reply({ fehler: "herkunft", text: "Diese Website ist für den Link-Dienst nicht freigeschaltet." }, 403, cors);

    try {
      if (path === "/anzeige") return reply(await anzeige(url.searchParams.get("url")), 200, cors);
      if (path === "/jobs") return reply(await jobs(url.searchParams), 200, cors);
      return reply({ fehler: "unbekannt", text: "Diese Adresse gibt es nicht." }, 404, cors);
    } catch (e) {
      return reply({ fehler: e.code || "fehler", text: e.publicText || "Das hat nicht geklappt." }, e.status || 502, cors);
    }
  }
};

/* ---------- Herkunft und Antworten ---------- */

function originAllowed(origin, env) {
  if (!origin || origin === "null") return false;
  const list = String((env && env.ALLOWED_ORIGINS) || "").split(",").map(s => s.trim().replace(/\/+$/, "")).filter(Boolean);
  if (list.includes("*")) return true;
  if (list.length) return list.includes(origin);
  try {
    const u = new URL(origin);
    return (u.protocol === "https:" && u.hostname.endsWith(".github.io")) || u.hostname === "localhost" || u.hostname === "127.0.0.1";
  } catch { return false; }
}

function reply(obj, status, extra) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
      "Referrer-Policy": "no-referrer",
      ...extra
    }
  });
}

function fail(code, publicText, status = 422) {
  const e = new Error(publicText);
  e.code = code; e.publicText = publicText; e.status = status;
  return e;
}

/* ---------- Sicheres Abrufen ---------- */

function checkTarget(raw) {
  let u;
  try { u = new URL(String(raw || "").trim()); } catch { throw fail("url", "Das ist kein gültiger Link.", 400); }
  if (!/^https?:$/.test(u.protocol)) throw fail("url", "Nur http- und https-Links gehen.", 400);
  if (u.username || u.password) throw fail("url", "Links mit Zugangsdaten gehen nicht.", 400);
  if (u.port && !["80", "443"].includes(u.port)) throw fail("url", "Dieser Link geht nicht.", 400);
  const h = u.hostname.toLowerCase().replace(/\.$/, "");
  if (!h.includes(".") || h === "localhost" || /\.(local|internal|localhost|lan|home|intranet|corp|arpa)$/.test(h)) throw fail("url", "Dieser Link geht nicht.", 400);
  if (/^\d+\.\d+\.\d+\.\d+$/.test(h) || h.startsWith("[") || h.includes(":")) throw fail("url", "Links mit IP-Adresse gehen nicht.", 400);
  u.hash = "";
  return u;
}

async function fetchLimited(href, headers, maxBytes, ms, maxRedirects = 4, beforeHop = null) {
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), ms);
  try {
    let cur = href;
    for (let hop = 0; hop <= maxRedirects; hop++) {
      if (beforeHop) await beforeHop(cur);
      const res = await fetch(cur, { headers, redirect: "manual", signal: ac.signal });
      const loc = res.headers.get("Location");
      if (res.status >= 300 && res.status < 400 && loc) {
        try { await res.body?.cancel(); } catch {}
        cur = checkTarget(new URL(loc, cur).href).href;
        continue;
      }
      const bytes = await readBody(res, maxBytes);
      return { status: res.status, url: cur, contentType: res.headers.get("Content-Type") || "", bytes };
    }
    throw fail("umleitung", "Der Link leitet zu oft weiter.");
  } catch (e) {
    if (e.code) throw e;
    const slow = e.name === "AbortError";
    throw fail(slow ? "zeit" : "netz", slow ? "Die Seite hat zu lange gebraucht." : "Die Seite war nicht erreichbar.", 504);
  } finally {
    clearTimeout(timer);
  }
}

async function readBody(res, max) {
  if (!res.body) return new Uint8Array(0);
  const reader = res.body.getReader();
  const chunks = []; let n = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    n += value.byteLength;
    if (n > max) { try { await reader.cancel(); } catch {} throw fail("zu_gross", "Die Seite ist zu groß.", 413); }
    chunks.push(value);
  }
  const out = new Uint8Array(n); let o = 0;
  for (const c of chunks) { out.set(c, o); o += c.byteLength; }
  return out;
}

function decode(bytes, contentType) {
  let cs = (/charset=["']?([\w-]+)/i.exec(contentType || "") || [])[1];
  if (!cs) {
    let head = ""; const n = Math.min(bytes.length, 4096);
    for (let i = 0; i < n; i++) head += String.fromCharCode(bytes[i]);
    cs = (/<meta[^>]+charset=["']?([\w-]+)/i.exec(head) || [])[1];
  }
  cs = (cs || "utf-8").toLowerCase();
  try { return new TextDecoder(cs).decode(bytes); } catch { return new TextDecoder("utf-8").decode(bytes); }
}

/* ---------- robots.txt (RFC 9309) ---------- */

async function getRobots(origin, cache) {
  if (cache.has(origin)) return cache.get(origin);
  let r;
  try {
    const res = await fetchLimited(origin + "/robots.txt", { "User-Agent": UA, "Accept": "text/plain,*/*;q=0.5" }, 500_000, 5_000, 4);
    if (res.status >= 400 && res.status < 500) r = { all: true };                 // keine robots.txt: alles erlaubt
    else if (res.status >= 500) r = { none: true };                               // Serverfehler: nichts erlaubt
    else r = { txt: decode(res.bytes, res.contentType) };
  } catch { r = { none: true }; }                                                 // nicht erreichbar: nichts erlaubt
  cache.set(origin, r);
  return r;
}

function robotsAllows(robots, pathAndQuery) {
  if (robots.all) return true;
  if (robots.none) return false;
  if (pathAndQuery === "/robots.txt") return true;
  const groups = []; let cur = null, lastAgent = false;
  for (let line of robots.txt.split(/\r?\n/)) {
    line = line.replace(/#.*$/, "").trim();
    const i = line.indexOf(":"); if (i < 0) continue;
    const key = line.slice(0, i).trim().toLowerCase(), val = line.slice(i + 1).trim();
    if (key === "user-agent") {
      if (!cur || !lastAgent) { cur = { agents: [], rules: [] }; groups.push(cur); }
      cur.agents.push(val.toLowerCase()); lastAgent = true;
    } else {
      lastAgent = false;
      if (cur && (key === "allow" || key === "disallow")) cur.rules.push({ allow: key === "allow", path: val });
    }
  }
  const token = UA_TOKEN.toLowerCase();
  let chosen = groups.filter(g => g.agents.some(a => a !== "*" && token.startsWith(a)));
  if (!chosen.length) chosen = groups.filter(g => g.agents.includes("*"));
  let best = null;
  for (const r of chosen.flatMap(g => g.rules)) {
    if (!r.path || !robotsMatch(r.path, pathAndQuery)) continue;
    if (!best || r.path.length > best.path.length || (r.path.length === best.path.length && r.allow)) best = r;
  }
  return !best || best.allow;
}

function robotsMatch(pattern, path) {
  const end = pattern.endsWith("$");
  const p = end ? pattern.slice(0, -1) : pattern;
  const re = "^" + p.split("*").map(s => s.replace(/[.+?^${}()|[\]\\]/g, "\\$&")).join(".*") + (end ? "$" : "");
  try { return new RegExp(re).test(path); } catch { return false; }
}

/* ---------- Text aus HTML ---------- */

const ENT = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: " ", auml: "ä", ouml: "ö", uuml: "ü", Auml: "Ä", Ouml: "Ö", Uuml: "Ü", szlig: "ß", euro: "€", ndash: "–", mdash: "—", bull: "•", hellip: "…", bdquo: "„", ldquo: "“", rdquo: "”", lsquo: "‘", rsquo: "’", sbquo: "‚", laquo: "«", raquo: "»", eacute: "é", egrave: "è", agrave: "à", ccedil: "ç", middot: "·", shy: "", zwnj: "", zwj: "" };
function decodeEntities(s) {
  return String(s).replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (m, e) => {
    if (e[0] === "#") {
      const n = e[1].toLowerCase() === "x" ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
      try { return n > 0 && n < 0x110000 ? String.fromCodePoint(n) : ""; } catch { return ""; }
    }
    return ENT[e] ?? ENT[e.toLowerCase()] ?? m;
  });
}

function htmlToText(h) {
  let s = String(h || "");
  if (/&lt;\/?[a-z]/i.test(s) && !/<[a-z]/i.test(s)) s = decodeEntities(s);   // HTML, das selbst noch kodiert ist
  return decodeEntities(s
      .replace(/<!--[\s\S]*?-->/g, " ")
      .replace(/<(script|style|noscript|svg|template|iframe)\b[^>]*>[\s\S]*?<\/\1\s*>/gi, " ")
      .replace(/<br\s*\/?>/gi, "\n")
      .replace(/<li\b[^>]*>/gi, "\n• ")
      .replace(/<\/(p|div|li|h[1-6]|tr|section|article|ul|ol|dd|dt|table|header|footer)\s*>/gi, "\n")
      .replace(/<[^>]+>/g, " "))
    .replace(/[ \t ​]+/g, " ")
    .replace(/ *\n */g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

const clean = v => (typeof v === "string" || typeof v === "number" ? String(v) : "").replace(/\s+/g, " ").trim().slice(0, 200);

function findPosting(node, depth = 0) {
  if (!node || depth > 6) return null;
  if (Array.isArray(node)) { for (const n of node) { const p = findPosting(n, depth + 1); if (p) return p; } return null; }
  if (typeof node === "object") {
    const types = [].concat(node["@type"] || []).map(t => String(t).toLowerCase());
    if (types.includes("jobposting")) return node;
    if (node["@graph"]) return findPosting(node["@graph"], depth + 1);
    if (node.mainEntity) return findPosting(node.mainEntity, depth + 1);
  }
  return null;
}

const UNIT = { HOUR: "std", MONTH: "monat", YEAR: "jahr", WEEK: "woche", DAY: "tag" };
function normalizePosting(p) {
  const name = v => typeof v === "string" ? v : (v && typeof v === "object" ? (v.name || v["@value"] || "") : "");
  const locs = [].concat(p.jobLocation || []);
  const addr = locs.map(l => l && typeof l === "object" ? (l.address || l) : l).find(Boolean) || {};
  const ort = typeof addr === "string" ? addr : (addr.addressLocality || addr.addressRegion || "");
  let lohn = null;
  const sal = [].concat(p.baseSalary || p.estimatedSalary || [])[0];
  if (sal) {
    const v = sal.value !== undefined ? sal.value : sal;
    const val = typeof v === "object" ? (v.value ?? v.minValue ?? v.maxValue) : v;
    const unit = String((typeof v === "object" && v.unitText) || sal.unitText || "").toUpperCase();
    const n = parseFloat(String(val).replace(",", "."));
    if (isFinite(n) && n > 0) lohn = { betrag: n, min: typeof v === "object" ? (v.minValue ?? null) : null, max: typeof v === "object" ? (v.maxValue ?? null) : null, einheit: UNIT[unit] || null };
  }
  return {
    titel: clean(name(p.title)),
    arbeitgeber: clean(name(p.hiringOrganization)),
    ort: clean(ort),
    plz: clean(addr.postalCode),
    beschreibung: htmlToText(p.description).slice(0, MAX_DESC),
    lohn,
    art: [].concat(p.employmentType || []).map(String).slice(0, 6),
    start: clean(p.jobStartDate) || null,
    arbeitszeitText: clean(p.workHours)
  };
}

function extractPage(html) {
  let posting = null;
  for (const m of html.matchAll(/<script[^>]+type=["']?application\/ld\+json["']?[^>]*>([\s\S]*?)<\/script>/gi)) {
    try { posting = findPosting(JSON.parse(m[1].trim().replace(/^<!--/, "").replace(/-->$/, ""))); } catch {}
    if (posting) break;
  }
  const meta = name => {
    const tag = (new RegExp(`<meta[^>]+(?:property|name)=["']${name}["'][^>]*>`, "i").exec(html) || [])[0];
    return tag ? clean(decodeEntities((/content=["']([^"']*)["']/i.exec(tag) || [])[1] || "")) : "";
  };
  const title = clean(decodeEntities((/<title[^>]*>([\s\S]*?)<\/title>/i.exec(html) || [])[1] || ""));
  const body = html.replace(/<head\b[^>]*>[\s\S]*?<\/head\s*>/i, " ").replace(/<(nav|form|select|button)\b[^>]*>[\s\S]*?<\/\1\s*>/gi, " ");
  const main = (/<main\b[\s\S]*?<\/main\s*>/i.exec(body) || /<article\b[\s\S]*?<\/article\s*>/i.exec(body) || [body])[0];
  return {
    posting: posting ? normalizePosting(posting) : null,
    titel: meta("og:title") || title,
    beschreibungMeta: meta("og:description") || meta("description"),
    text: htmlToText(main).slice(0, MAX_TEXT)
  };
}

/* ---------- /anzeige ---------- */

async function anzeige(raw) {
  const u = checkTarget(raw);
  const ref = baRefnr(u);
  if (ref) {
    const d = await baDetails(ref);
    if (d) return { quelle: "Jobbörse der Bundesagentur für Arbeit", url: BA_WEB + encodeURIComponent(ref), strukturiert: true, ...normDetail(d, ref) };
  }
  const robots = new Map();
  const res = await fetchLimited(u.href, {
    "User-Agent": UA,
    "Accept": "text/html,application/xhtml+xml;q=0.9,text/plain;q=0.8,*/*;q=0.5",
    "Accept-Language": "de-DE,de;q=0.9"
  }, MAX_PAGE_BYTES, TIMEOUT_MS, 4, async hop => {
    const x = new URL(hop);
    if (!robotsAllows(await getRobots(x.origin, robots), x.pathname + x.search))
      throw fail("robots", "Diese Seite erlaubt kein automatisches Lesen. Kopiere den Text der Anzeige bitte selbst.", 403);
  });
  if (res.status === 404 || res.status === 410) throw fail("weg", "Die Anzeige gibt es nicht mehr.", 404);
  if (res.status === 401 || res.status === 403 || res.status === 429) throw fail("gesperrt", "Die Seite lässt den Link-Dienst nicht hinein. Kopiere den Text bitte selbst.", 403);
  if (res.status >= 400) throw fail("http", "Die Seite hat einen Fehler gemeldet.", 502);
  const ct = res.contentType.toLowerCase();
  if (ct.includes("pdf")) throw fail("pdf", "Die Anzeige ist ein PDF. Kopiere den Text bitte selbst.", 415);
  if (ct && !/html|xml|text\/plain/.test(ct)) throw fail("format", "Unter dem Link steht keine lesbare Seite.", 415);
  const html = decode(res.bytes, res.contentType);
  const page = ct.includes("text/plain") ? { posting: null, titel: "", beschreibungMeta: "", text: html.slice(0, MAX_TEXT) } : extractPage(html);
  const p = page.posting;
  return {
    quelle: new URL(res.url).hostname.replace(/^www\./, ""),
    url: res.url,
    strukturiert: !!p,
    titel: (p && p.titel) || page.titel,
    arbeitgeber: (p && p.arbeitgeber) || "",
    ort: (p && p.ort) || "",
    plz: (p && p.plz) || "",
    lohn: (p && p.lohn) || null,
    art: (p && p.art) || [],
    arbeitszeitText: (p && p.arbeitszeitText) || "",
    beschreibung: (p && p.beschreibung) || page.beschreibungMeta || "",
    text: p && p.beschreibung && p.beschreibung.length > 400 ? "" : page.text
  };
}

/* ---------- Jobbörse der Bundesagentur für Arbeit ---------- */

function baRefnr(u) {
  if (!/(^|\.)arbeitsagentur\.de$/.test(u.hostname)) return null;
  const m = /\/jobsuche\/jobdetail\/([^/?#]+)/.exec(u.pathname);
  return m ? decodeURIComponent(m[1]) : null;
}

async function baFetch(path) {
  const res = await fetchLimited(BA_BASE + path, { "X-API-Key": BA_KEY, "Accept": "application/json", "User-Agent": UA }, 3_000_000, TIMEOUT_MS, 2);
  if (res.status !== 200) return null;
  try { return JSON.parse(new TextDecoder("utf-8").decode(res.bytes)); } catch { return null; }
}

async function baDetails(refnr) {
  const code = btoa(unescape(encodeURIComponent(refnr)));
  for (const v of ["v4", "v3"]) {
    const d = await baFetch(`/pc/${v}/jobdetails/${code}`).catch(() => null);
    if (d && typeof d === "object" && (d.stellenangebotsTitel || d.titel || d.stellenangebotsBeschreibung || d.stellenbeschreibung)) return d;
  }
  return null;
}

function normDetail(d, refnr) {
  const o = [].concat(d.arbeitsorte || [])[0] || {};
  const verg = typeof d.verguetung === "string" ? d.verguetung : "";
  return {
    refnr: d.refnr || d.referenznummer || refnr,
    titel: clean(d.stellenangebotsTitel || d.titel || d.beruf),
    beruf: clean(d.beruf),
    arbeitgeber: clean(d.arbeitgeber),
    ort: clean(o.ort),
    plz: clean(o.plz),
    beschreibung: htmlToText(d.stellenangebotsBeschreibung || d.stellenbeschreibung || "").slice(0, MAX_DESC),
    arbeitszeit: [].concat(d.arbeitszeitmodelle || []).map(String),
    befristung: clean(d.befristung) || null,
    verguetung: clean(verg),
    angebotsart: clean(d.angebotsart) || null,
    eintritt: clean(d.eintrittsdatum) || null,
    veroeffentlicht: clean(d.aktuelleVeroeffentlichungsdatum) || null
  };
}

function normItem(it) {
  const o = it.arbeitsort || [].concat(it.arbeitsorte || [])[0] || {};
  const refnr = clean(it.refnr || it.referenznummer);
  const km = o.entfernung ?? it.entfernung;
  return {
    refnr,
    titel: clean(it.titel || it.stellenangebotsTitel || it.beruf),
    beruf: clean(it.beruf),
    arbeitgeber: clean(it.arbeitgeber),
    ort: clean(o.ort),
    plz: clean(o.plz),
    entfernung: km != null && isFinite(+km) ? +km : null,
    eintritt: clean(it.eintrittsdatum) || null,
    veroeffentlicht: clean(it.aktuelleVeroeffentlichungsdatum) || null,
    url: BA_WEB + encodeURIComponent(refnr),
    beschreibung: "",
    arbeitszeit: [],
    details: false
  };
}

const ANGEBOT = new Set(["1", "4", "34"]);
const ARBEITSZEIT = new Set(["vz", "tz", "snw", "ho", "mj"]);
const int = (v, lo, hi, def) => { const n = parseInt(v, 10); return isFinite(n) ? Math.min(hi, Math.max(lo, n)) : def; };

async function jobs(q) {
  const s = k => String(q.get(k) || "").replace(/[\u0000-\u001f<>"]/g, "").trim().slice(0, 80);
  const was = s("was"), wo = s("wo");
  if (!was && !wo) throw fail("eingabe", "Gib ein Suchwort oder einen Ort an.", 400);
  const p = new URLSearchParams();
  if (was) p.set("was", was);
  if (wo) { p.set("wo", wo); p.set("umkreis", String(int(q.get("umkreis"), 0, 200, 25))); }
  const art = s("angebotsart");
  p.set("angebotsart", ANGEBOT.has(art) ? art : "1");
  const az = s("arbeitszeit").split(";").filter(x => ARBEITSZEIT.has(x));
  if (az.length) p.set("arbeitszeit", az.join(";"));
  p.set("veroeffentlichtseit", String(int(q.get("seit"), 1, 100, 60)));
  p.set("size", String(int(q.get("anzahl"), 1, 25, 15)));
  p.set("page", String(int(q.get("seite"), 1, 20, 1)));

  let data = null;
  for (const path of ["/pc/v4/jobs", "/pc/v6/jobs", "/pc/v4/app/jobs"]) {
    data = await baFetch(path + "?" + p.toString()).catch(() => null);
    if (data && Array.isArray(data.stellenangebote)) break;
    if (data && data.maxErgebnisse !== undefined && !data.stellenangebote) { data.stellenangebote = []; break; }   // keine Treffer
    data = null;
  }
  if (!data) throw fail("jobboerse", "Die Jobbörse antwortet gerade nicht.", 502);

  const items = data.stellenangebote.map(normItem).filter(x => x.refnr);
  const nDet = int(q.get("details"), 0, 12, 10);
  await Promise.all(items.slice(0, nDet).map(async it => {
    const d = await baDetails(it.refnr).catch(() => null);
    if (!d) return;
    const n = normDetail(d, it.refnr);
    for (const [k, v] of Object.entries(n)) if (v && (!Array.isArray(v) || v.length)) it[k] = v;
    it.details = true;
  }));
  return {
    quelle: "Jobbörse der Bundesagentur für Arbeit",
    gesamt: +data.maxErgebnisse || items.length,
    suche: Object.fromEntries(p),
    angebote: items
  };
}
